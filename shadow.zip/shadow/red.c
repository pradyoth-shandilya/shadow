#include <opencv2/opencv.hpp>
#include <iostream>

using namespace cv;
using namespace std;

int main(int argc, char* argv[])
{
//Open the default video camera
VideoCapture cap(0);
 // if not success, exit program
if (cap.isOpened() == false)  
{
cout << "Cannot open the video camera" << endl;
cin.get(); //wait for any key press
return -1;
} 
double dWidth = cap.get(CAP_PROP_FRAME_WIDTH); //get the width of frames of the video
double dHeight = cap.get(CAP_PROP_FRAME_HEIGHT); //get the height of frames of the video
cout << "Resolution of the video : " << dWidth << " x " << dHeight << endl;
string window_name = "My Camera Feed";
//namedWindow(window_name); //create a window called "My Camera Feed"
int frame_width=   cap.get(CV_CAP_PROP_FRAME_WIDTH);
   int frame_height=   cap.get(CV_CAP_PROP_FRAME_HEIGHT);
   VideoWriter video("outputVid.avi",CV_FOURCC('M','J','P','G'),10, Size(frame_width,frame_height),true);
while (true)
{
cout<<"In the main loop"<<endl;
Mat frame;
Mat gray;
Mat blurred;
Mat thresh;
bool bSuccess = cap.read(frame); // read a new frame from video 
Mat copy = frame.clone();

cvtColor(frame,gray,CV_BGR2GRAY);
GaussianBlur(gray,blurred,Size(11,11),0);

threshold(blurred,thresh, 200, 255, THRESH_BINARY);
double i = 0;
double j = 0;

for(i=0;i<dWidth;i++)
{
for(j=0;j<dHeight;j++)
{

Scalar bw = thresh.at<uchar>(Point(i,j));
if(bw.val[0]==255)
{
	int tx = i;//Temporary x values
	int ty = j;//Temporary y values
	int flag = 0;//Flag to exit the loop. Can be potentially replaced with one or more break statements
	int isRed = 0;//Variable that tells whether the range of pixels is red dominant or not. By default, it's set to zero which means "not red"
	int minX = 0;//minX is the least pixel in the x parallel axis from where a red region starts
	int maxX = 0;//maxX is the last pixel in the x parallel axis from where a red region ends
	/*
	If a region turns out to be "not red", all the pixels between minX and maxX are obviously true bright pixels 
	These pixels are dimmed in one single operation instead of processing all the pixels for brightness again
	*/
	int loopX = 0;
cout<<"HEre"<<endl;
	while(flag==0)
	{
		cout<<"Enter flag while"<<endl;
		Scalar temp = thresh.at<uchar>(Point(tx,ty));
		if(temp.val[0]==255)
		{
			if(tx>0)
			tx--;
			cout<<"Entering main flag if"<<endl;
		}
		else
		{
			cout<<"Entering main flag else at x="<<tx<<endl;
			//lc is a loop counter. It counts 30 pixels backwards
			int lc = 0;
			while(tx>0 && lc<300)
			{
				tx--;
				lc++;
			

			/*
				Here, we check if these individual pixels are red dominant or not. If it is red dominant, the code intends to skip
				processing over that range of white pixels
			*/
			double pixBlue = (double)frame.at<Vec3b>(ty,tx)[0];
			double pixGreen = (double)frame.at<Vec3b>(ty,tx)[1]
			double pixRed = (double)frame.at<Vec3b>(ty,tx)[2]
			cout<<"Blue is "<<pixBlue<<endl;
			cout<<"Green is "<<pixGreen<<endl;
			cout<<"Red is "<<pixRed<<endl;

			if(pixRed > pixBlue && pixRed > pixGreen)
			{
				cout<<"Red detected!"<<endl;
				//
				minX = tx;
				tx=i;
				while(thresh.at<uchar>(Point(tx,ty))==255 && tx<dWidth)
				{
					tx++;				
				}
				if(tx<dWidth-1)
				{
					i = tx+1;
					break;
				}
				else
				{
					j = j+1;
				}
				maxX = tx;
				flag = 1;
				isRed = 1;
			}
			else
			{
				flag = 1;
			}
		}
	}
	}
if(isRed != 0)
{
	for(loopX = minX; loopX < maxX; loopX++)
double mean = ((double)frame.at<Vec3b>(j,loopX)[0] + (double)frame.at<Vec3b>(j,loopX)[1] + (double)frame.at<Vec3b>(j,loopX)[2])/3;
double dim = mean/140;
frame.at<Vec3b>(Point(loopX,j)) = frame.at<Vec3b>(Point(loopX,j))/dim;
}
}

}
}

//Breaking the while loop if the frames cannot be captured
if (bSuccess == false) 
{
cout << "Video camera is disconnected" << endl;
cin.get(); //Wait for any key press
break;
}

  //show the frame in the created window
imshow("Frame", frame);
video.write(frame);
//imshow("gray", gray);
//imshow("blurred",blurred);
imshow("thresh",thresh);
imshow("Original", copy);
//wait for for 10 ms until any key is pressed.  
//If the 'Esc' key is pressed, break the while loop.
//If the any other key is pressed, continue the loop 
//If any key is not pressed withing 10 ms, continue the loop 
if (waitKey(10) == 27)
{
cout << "Esc key is pressed by user. Stopping the video" << endl;
break;
}
}

return 0;

}
